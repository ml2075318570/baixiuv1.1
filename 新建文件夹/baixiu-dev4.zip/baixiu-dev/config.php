<?php

/**
 * 我们项目中用到的配置信息
 */

/**
 * 数据库主机
 */
define('XIU_DB_HOST', 'localhost');
/**
 * 数据库用户名
 */
define('XIU_DB_USER', 'root');
/**
 * 数据库密码
 */
define('XIU_DB_PASS', '123456');
/**
 * 数据库名字
 */
define('XIU_DB_NAME', 'baixiu-dev');

// D:\www\baixiu-dev\config.php
// D:\www\baixiu-dev
define('ROOT_DIR', dirname(__FILE__));
