<?php

/**
 * 我们项目中用到的配置信息
 */

/**
 * 数据库主机
 */
define('DB_HOST', 'localhost');
/**
 * 数据库用户名
 */
define('DB_USER', 'root');
/**
 * 数据库密码
 */
define('DB_PASS', '123456');
/**
 * 数据库名字
 */
define('DB_NAME', 'baixiu');
