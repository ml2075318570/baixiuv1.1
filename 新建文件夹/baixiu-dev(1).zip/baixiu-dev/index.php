<?php

require_once 'config.php';

?>
<h1>前台页面</h1>

<p><?php echo DB_USER; ?></p>
