<?php echo $foo; ?>
