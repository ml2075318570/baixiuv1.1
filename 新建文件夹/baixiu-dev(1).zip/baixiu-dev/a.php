<?php
$foo = 123;
include 'b.php';
?>
